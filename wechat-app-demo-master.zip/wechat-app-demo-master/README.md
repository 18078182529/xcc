## webApp-demo

![](./demo.png)

微信小程序 demo / 开发工具 / 文档资源

为了方便更新, 后续资源全部更新到 [wiki](https://github.com/xwartz/wechatApp-demo/wiki)


### 资源

*官方已经提供了，无需破解了，具体看以下链接。*

官方文档: https://mp.weixin.qq.com/debug/wxadoc/dev/?t=1474643026176

开发工具: https://mp.weixin.qq.com/debug/wxadoc/dev/devtools/download.html?t=1474644089359

